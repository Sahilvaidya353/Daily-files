package Inheritance;

public class HigherEducation extends SchoolEducation {
protected String streams;

public HigherEducation(String deptName, int courses, int noOfPepole, int noOfTeachers, int subjects, String streams) {
	super(deptName, courses, noOfPepole, noOfTeachers, subjects);
	this.streams = streams;
}

@Override
public String toString() {
	return "HigherEducation [streams=" + streams + ", noOfTeachers=" + noOfTeachers + ", subjects=" + subjects
			+ ", deptName=" + deptName + ", courses=" + courses + ", noOfPepole=" + noOfPepole + "]";
}



}
