package Inheritance;

public class TestPerson {

	public static void main(String[] args) {
		Person person = new Person("sahil", 24, 'M');
		System.out.println(person);//will to call toString()
		person.display();
		person.fun1();
		
		System.out.println("=====================");
		Student student = new Student("Sahil", 24, 'M', 02, "Mechanical", 82);
		System.out.println(student);
		System.out.println("=====================");
		Employee employee = new Employee("Sahil", 24, 'M', 02, "MEchanical", 82, 1235, "tata", 40000);
	    System.out.println(employee);
	    //binding
	    System.out.println("=====================");
	    Person person2=new Person("Sahil",24, 'M');
	    System.out.println(person2);
	    System.out.println("=====================");
	    person2=new Student("Yash", 21, 'M', 67, "CS", 70);
	    System.out.println(person2);
	}

}
