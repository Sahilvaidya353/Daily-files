package module3;
import java.util.Scanner;
public class IFDemo2 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int num1=sc.nextInt();
		int num2=sc.nextInt();

		if(num1>num2) {
			System.out.println("Num1 is greater than Num2");
		}
		else if(num1 < num2 ){
			System.out.println("Num2 is greater than Num1");
		}
		else {
			System.out.println("num1 is equal to num2");
		}
	}

}
