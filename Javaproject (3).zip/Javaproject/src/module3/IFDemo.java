package module3;
import java.util.Scanner;
public class IFDemo {

	public static void main(String[] args) {
		Scanner sc =new Scanner(System.in);
		System.out.println("enter a number");
		int num=sc.nextInt();
		
		if(num > 0) {
			System.out.println("The number is +ve");
		}
		else if(num <0) {
			System.out.println("The numbe is -ve");
		}
		else {
			System.out.println("The number is zero");
		}

	}

}
