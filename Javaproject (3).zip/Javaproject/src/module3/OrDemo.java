package module3;

public class OrDemo {
	public static void main(String[] args) {
		int a=3030;
		int b=3000;
		int c=233;
		
		if (a==b)
			System.out.println("same");
		if(a>b || a>c)
			System.out.println("any one of the condition is true..");
		if(a!=b)
			System.out.println("both are  different");
	}
}
