package module5;

public class Temporary {
	public static void main() {
		System.out.println("Main method without parameters");
	}
	public static void main(int a,int b) {
	System.out.println("Main method with 2 parameters");
}
	public static void main(int a) {
	System.out.println("Main method with 1 parameters");
}

	public static void main(String[] args) {
		 main();
		 main(10,20);
		 main(12);

	}

}
