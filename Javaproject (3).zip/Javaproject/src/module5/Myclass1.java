package module5;

class Myclass2 {
	public void fun2() {
		System.out.println("This is fun1");
	}
}

class Myclass3 {
	public void fun1() {
		System.out.println("This is fun2");
	}
}

public class Myclass1 {
	public static void main(String[] args) {
		Myclass3 myclass3 = new Myclass3();
		myclass3.fun1();

		Myclass2 myclass2 = new Myclass2();
		myclass2.fun2();
	}
}
