package Assignment3;

public class Bank {
	protected  int accNo;
	protected  String accHolderName;
	protected  double accountbalance;
	public Bank(int accNo, String accHolderName, double accountbalance) {
		super();
		this.accNo = accNo;
		this.accHolderName = accHolderName;
		this.accountbalance = accountbalance;
	}
	public int getAccNo() {
		return accNo;
	}
	public void setAccNo(int accNo) {
		this.accNo = accNo;
	}
	public String getAccHolderName() {
		return accHolderName;
	}
	public void setAccHolderName(String accHolderName) {
		this.accHolderName = accHolderName;
	}
	public double getAccountbalance() {
		return accountbalance;
	}
	public void setAccountbalance(double accountbalance) {
		this.accountbalance = accountbalance;
	}

	
	
	
	
}
