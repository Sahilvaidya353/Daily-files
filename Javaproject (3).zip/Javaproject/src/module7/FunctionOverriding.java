package module7;

class Shape {
	void calArea(String shape, int a, int b) {
		System.out.println("calArea of shape class");
	}

	void display() {
		System.out.println("display of shape class");
	}

	void fun1() {
		System.out.println();
	}
}

class Rectangle extends Shape {
	void calArea(String shape, int a, int b) {
		System.out.println("Area is" + (a * b));
	}

	void display() {
		super.display();
		super.fun1();
	}
}

public class FunctionOverriding {
	public static void main(String[] args) {
		Shape shape = new Shape();
		shape.calArea("shape", 10, 20);
		shape.display();
		System.out.println("============");
		Rectangle rect = new Rectangle(); // static binding
		rect.calArea("rectangle", 30, 40);
		rect.display();

		System.out.println("==============");
		shape = new Rectangle(); // dynamic binding
		shape.calArea("rect", 10, 30);// calls calArea or Rectangle class
		shape.display();
	}
}
