package Assignment5;

public class Student {
private String name;
private int age;
private String address;
public Student(String name, int age, String address) {
	super();
	this.name = name;
	this.age = age;
	this.address = address;
}

public void setinfo() {
	
}
}
