package module1;

public class Myclass2 {
	public static void main(String args[]) {
		int empno=100;
		String ename="Sahil";
		double sal=300000.50;
		float comm=1000.6f;
		float bonus=(float)500.55;
		byte b=100;
		short s=2000;
		long l= 892359382;
		char gender='M';
		boolean passStatus=true;
		
		System.out.println("empno is "+empno);
		System.out.println("Salary is "+sal);
		System.out.println("comm is "+comm);
		System.out.println("Bonus is" +bonus);
		System.out.println("B is "+ b);
		System.out.println("Short "+s);
		System.out.println("long  "+l);
		System.out.println("Gender "+gender);
		System.out.println("Pass Status "+passStatus);
	}

}
