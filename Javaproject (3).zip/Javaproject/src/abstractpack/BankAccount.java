package abstractpack;

abstract class BankAccount {
protected int id;
protected float balance;

abstract public void calculateInterest();

public BankAccount(int id, float balance) {
	super();
	this.id = id;
	this.balance = balance;
}

}
class CurrentAccount extends BankAccount{
	
	
	public CurrentAccount(int id, float balance) {
		super(id, balance);
		// TODO Auto-generated constructor stub
	}

	public void calculateInterest() {
		System.out.println(0.07f*balance);
	}
}
class SavingsAccount extends BankAccount{

	public SavingsAccount(int id, float balance) {
		super(id, balance);
		// TODO Auto-generated constructor stub
	}
	public void calculateInterest() {
		System.out.println(0.056f*balance);
	}
	
}
class LoanAccount extends BankAccount{

	public LoanAccount(int id, float balance) {
		super(id, balance);
		// TODO Auto-generated constructor stub
	}
	public void calculateInterest() {
		System.out.println(0.1f*balance);
	}
	
}


