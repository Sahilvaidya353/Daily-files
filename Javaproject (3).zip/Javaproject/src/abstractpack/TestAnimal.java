package abstractpack;

abstract class Animal {
	final int legs = 4;

	abstract public void sound();

	abstract public void fun1();

	abstract public void fun2();

	public void classInfo(String type) {
		System.out.println("I belongs to " + type + " has " + legs + "legs");
	}
}

class Dog extends Animal {
	public void sound() {
		System.out.println("The dog barks...");
	}

	public void fun1() {
		System.out.println("This is fun1");
	}

	public void fun2() {
		System.out.println("This is fun2");
	}
}

class Lion extends Animal {
	public void sound() {
		System.out.println("The lion roars...");
	}

	public void fun1() {
		System.out.println("This is fun1");
	}

	public void fun2() {
		System.out.println("This is fun2");
	}
}

public class TestAnimal {

	public static void main(String[] args) {
		Dog dog = new Dog();
		dog.classInfo("Dog");
		dog.sound();
		dog.fun1();
		dog.fun2();
		Lion lion = new Lion();
		lion.classInfo("Lion");
		lion.sound();
		lion.fun1();
		lion.fun2();
	}

}
