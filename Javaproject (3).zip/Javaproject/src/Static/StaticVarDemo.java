package Static;

public class StaticVarDemo {
	static int num = 1;

	public void display() {
		num++;
		System.out.println(num);

	}

	public static void main(String[] args) {
		System.out.println(num);              // 1 method
		System.out.println(StaticVarDemo.num);//2  method
		
		StaticVarDemo obj= new StaticVarDemo();
		obj.display();
		StaticVarDemo obj1=new StaticVarDemo();
		obj1.display();
		StaticVarDemo obj2=new StaticVarDemo();
		obj2.display();

	}

}
