package Stringpack;

public class StringDemo {

	public static void main(String[] args) {
		String str = new String("   Sahil");
		String str2 = new String("   Vaidya");
		System.out.println(str.substring(3));
		System.out.println(str.substring(3, 5));
		System.out.println(str.trim());
		System.out.println(str.toUpperCase());
		System.out.println(str.toLowerCase());
		System.out.println(str.indexOf("a"));
		System.out.println(str.replace("i", "ee"));
		System.out.println(str.concat(str2));
		if(str.equals(str2))
			System.out.println("same");
		String[] arr=str.split(" ");
		for(String s:arr) {
			System.out.println(s);
		}
	}

}
