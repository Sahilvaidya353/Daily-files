package module4;

public class TestUser {

	public static void main(String[] args) {
		User user =new User();
		user.accept();
		user.checkAge();
		user.checksal();
		user.display();

	}

}
