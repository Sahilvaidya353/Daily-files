package interfacepack;

public interface Graphic {
	float PI = 3.14f;
	float area();
	float perimeter();
}
