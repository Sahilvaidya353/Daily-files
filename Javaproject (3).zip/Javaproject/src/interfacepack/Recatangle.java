package interfacepack;

public class Recatangle implements Graphic {
private float l,b;
	

	public Recatangle(float l, float b) {
	super();
	this.l = l;
	this.b = b;
}

	@Override
	public float area() {
		// TODO Auto-generated method stub
		return(l*b);
	}

	@Override
	public float perimeter() {
		// TODO Auto-generated method stub
		return(2*(l+b));
	}

}
