package Inheritance;

public class Student extends Person {
	protected int rollNo;
	protected String stream;
	protected int score;

	public Student(String name, int age, char gender, int rollNo, String stream, int score) {
		super(name, age, gender); // calling constructor of parent class
		this.rollNo = rollNo;
		this.stream = stream;
		this.score = score;
	}

	public void display() {//fun overriding
		super.display();//calling the method from parent class
		super.fun1();
	}

	@Override
	public String toString() {
		return "Student [rollNo=" + rollNo + ", stream=" + stream + ", score=" + score + ", name=" + name + ", age="
				+ age + ", gender=" + gender + "]";
	}


}
