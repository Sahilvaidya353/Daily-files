package Inheritance;

public class TestDepartment {

	public static void main(String[] args) {
		Department department = new Department("Education Department", 2, 2000);
		System.out.println(department);
		System.out.println("================");
		SchoolEducation schooleducation = new SchoolEducation("primary education", 5, 550, 90, 5);
		System.out.println(schooleducation);
	}

}
