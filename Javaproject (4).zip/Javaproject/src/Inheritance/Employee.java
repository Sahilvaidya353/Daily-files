package Inheritance;

public class Employee extends Student {

	private int empno;
	private String cname;
	private double salary;
	public Employee(String name, int age, char gender, int rollNo, String stream, int score, int empno, String cname,
			double salary) {
		super(name, age, gender, rollNo, stream, score);
		this.empno = empno;
		this.cname = cname;
		this.salary = salary;
	}
	@Override
	public String toString() {
		return "Employee [empno=" + empno + ", cname=" + cname + ", salary=" + salary + ", rollNo=" + rollNo
				+ ", stream=" + stream + ", score=" + score + ", name=" + name + ", age=" + age + ", gender=" + gender
				+ "]";
	}
	
	
}
