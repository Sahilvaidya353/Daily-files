package Assignment6;
abstract class GeometricShape{
	final double PI=3.14;
	abstract public void area();

	abstract public void perimeter();

class Circle extends GeometricShape{
	int r;
	public void area() {
		System.out.println(PI*r*r);
	}
	public void perimeter() {
		System.out.println(2*PI*r*r);
	}
}
}
class Rectangle extends  GeometricShape{
	
}
public class TestGeometricShape {
	public static void main(String)
	
}


