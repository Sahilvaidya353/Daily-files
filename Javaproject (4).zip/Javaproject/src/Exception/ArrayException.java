package Exception;

public class ArrayException {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	int[] arr = {10,200,30,40,60};
	try {
		
		System.out.println(arr[10]);
	}catch(ArrayIndexOutOfBoundsException e){
		System.out.println("Array size is incorrect");
		System.out.println("The size of array is "+arr.length);
		e.getMessage();
	}
 }
}
