package Exception;
import java.util.Scanner;

class CheckPassword extends Exception{
	public CheckPassword(String msg) {
		super(msg);
	}
}
public class CustomExceptionDemo {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the password");
		String password = sc.next();
		try {
			if(password.length()<8)
				throw new CheckPassword("password length should be more than 8 ch...");
			else if(password.matches("[A-Za-z0-9 ]*"))
				throw new CheckPassword("Password should have special charecters");
			else
				System.out.println("Valid password");
		}catch(Exception e){
			System.out.println(e.getMessage());
		}
	}

}
