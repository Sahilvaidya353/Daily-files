package Exception;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

public class CheckedfExceptionDemo {

	public static void main(String[] args) throws IOException
	{
		try {
			FileInputStream fis = new FileInputStream("D:\\Sahil\\myfile12.txt");
			int k;
			while ((k = fis.read()) != -1) { // -1 = till end of the file (to check EOF)
				System.out.print((char) k);
			}
			fis.close();
		} catch (FileNotFoundException e) {
			System.out.println("Error : path is wrong for the file,check the path.....");
		}

	}
}