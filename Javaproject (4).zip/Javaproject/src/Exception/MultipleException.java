package Exception;

import java.util.Scanner;

public class MultipleException {
	public static double divide(int num1, int num2) {
		return (num1 / num2);
	}

	public static double sub(int num1, int num2) {
		return (num1 - num2);
	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the two values");
		String str = sc.next();
		String str1 = sc.next();
		try {
			int num1 = Integer.parseInt(str);
			int num2 = Integer.parseInt(str1);

			double result = divide(num1, num2);
			System.out.println("result is " + result);
		} catch (ArithmeticException e) {
			System.out.println("We can not divivde number by zero");

		} catch (NumberFormatException e1) {
			System.out.println("The value return is string not number");

		} catch (Exception e) {
			System.out.println("Error: There is an error");

		} finally {
			System.out.println("This is final block");
		}
	}

}
