package Assignment;

public class TestAssignment1 {

	public static void main(String[] args) {
		Assignment1 assignment1=new Assignment1();
		assignment1.accept();
		assignment1.loanEligible();
		assignment1.Display();
	}

}
