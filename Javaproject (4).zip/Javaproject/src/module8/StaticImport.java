package module8;
import static java.lang.Math.*;
public class StaticImport {

	public static void main(String[] args) {
		System.out.println(pow(3,2));
		System.out.println(random());
		System.out.println(min(4,7));
		System.out.println(max(8,6));
		System.out.println(abs(-78));
		System.out.println(round(7.8));
		
	}

}
