package module6;

import java.util.Scanner;

public class TestCustomer {

	public static void main(String[] args) {
		Customer customer=new Customer();
//		System.out.println("custID "+customer.getCustId());	
//		System.out.println("name "+customer.getCustId());
//		System.out.println("mobile no "+customer.getMobile());
//		System.out.println("address "+customer.getAddress());
		
		System.out.println("==============");
		Customer customer2=new Customer(2323,"sahil",696634526,"xyz");
//		System.out.println("custID "+customer2.getCustId());
//		System.out.println("name "+customer2.getName());
//		System.out.println("mobile no "+customer2.getMobile());
//		System.out.println("address "+customer2.getAddress());
		
		System.out.println(customer2);	
		
	}

}
