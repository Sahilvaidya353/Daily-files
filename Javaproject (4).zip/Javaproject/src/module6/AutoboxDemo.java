package module6;

public class AutoboxDemo {

	public static void main(String[] args) {
		
		int a=100;
		Integer i=a;   	//Autoboxing
		System.out.println("============");
		int a1=i;	    //Unboxing
		
		System.out.println(i);
		System.out.println(a1);
	}

}
