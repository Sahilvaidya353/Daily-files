package module1;

public class EducationDepartment {
private String DepartmentType;
		int NoOfFaculty,ceid,age;
		int NoOFStudents;
		String TypeOfCourse;
		String name,gender;
		int marks;
public void addcourse() {
	System.out.println("Add Course "+TypeOfCourse);
}
public void courseEnrollment() {
	System.out.println("Course Enrollment"+ceid);
}
public void Display_StudentRecord(){
	System.out.println("Name"+name);
	System.out.println("Age"+age);
	System.out.println("Gender"+gender);
	System.out.println("Marks of Student"+marks);
}	
public void Display_FacultyRecord(){
	System.out.println("Name"+name);
	System.out.println("Age"+age);
	System.out.println("Gender"+gender);
}	
public void UpdateDepartment() {
	System.out.println("Update new department"+DepartmentType);
}
public static void main(String args[]) {
	System.out.println("Creating an object");
	EducationDepartment educationdepartment = new EducationDepartment();
	educationdepartment.name="Ahuas";
	educationdepartment.age=19;
	educationdepartment.gender="male";
	educationdepartment.marks=56;
	System.out.println("faculty record");
	educationdepartment.name="akaeig";
	educationdepartment.age=45;
	educationdepartment.gender="male";
}
}
