package Assignment3;

public class BankA {

}
