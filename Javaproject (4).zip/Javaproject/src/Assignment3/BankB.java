package Assignment3;

public class BankB {

}
