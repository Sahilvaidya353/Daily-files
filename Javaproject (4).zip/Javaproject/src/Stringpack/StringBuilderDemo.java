package Stringpack;

public class StringBuilderDemo {

	public static void main(String[] args) {
		StringBuilder sb=new StringBuilder("Sahil");
		sb.insert(4, "new text");
		System.out.println(sb);
		sb.append("CDAC Nashik");
		System.out.println(sb);
		
		int i=sb.indexOf("h");
		System.out.println("i is "+i);
		int i1=sb.lastIndexOf("a");
		System.out.println("i1 is "+i1);
		sb.replace(3, 6 , " new ");
		System.out.println(sb);
		sb.delete(0, 4);
		System.out.println(sb);
	}

}
