package Stringpack;

public class StringBufferDemo {

	public static void main(String[] args) {
		StringBuffer sb = new StringBuffer("sahil");
		sb.append("CDAC Nashik");
		System.out.println(sb);
		
		int i=sb.indexOf("h");
		System.out.println("i is "+i);
		int i1=sb.lastIndexOf("a");
		System.out.println("i1 is "+i1);
		sb.replace(3, 6 , " new ");
		System.out.println(sb);
		sb.delete(0, 4);
		System.out.println(sb);
		System.out.println(sb.reverse());

	}

}
