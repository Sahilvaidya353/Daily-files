package module4;

import java.util.Scanner;

public class Employee {
	private String ename;
	private int empNo;
	private double balance;
	Scanner sc=new Scanner(System.in);

	public void accept() {
		System.out.println("Enter the name, age, salary");
		ename= sc.next();
		empNo = sc.nextInt();
		balance = sc.nextDouble();
	}
	public void checkEmpNo() {
		if(empNo>0) {
			System.out.println("Valid Employee number ");
		}
		else
			System.out.println("invalid Employee number");
		}
	public void checkbal() {
		
		if(balance>0 && balance<100000) {
			System.out.println(" valid balance ");
		}
		else if(balance>100000){
			System.out.println("Produce proof");
		}
		else {
			System.out.println("Invalid balance");
		}
	}
	public void display()
	{
		System.out.println("Name"+ename);
		System.out.println("Age"+empNo);
		System.out.println("Salary"+balance);
}
}
