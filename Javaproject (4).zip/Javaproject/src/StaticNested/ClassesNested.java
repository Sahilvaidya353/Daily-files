package StaticNested;
class OuterClass{
	private static String msg="Welcome to Nested loop";
	public static class NestedStaticClass{
		public void printMessage() {
			System.out.println("Message from neseted static class: "+msg);

		}
	}
	public class InnerClass{
		public void display() {
			System.out.println("message from non static nested class: "+msg);
		}
	}
}
public class ClassesNested {

	public static void main(String[] args) {
		// 1obj created static class
		OuterClass.NestedStaticClass printer = new OuterClass.NestedStaticClass();
		printer.printMessage();
		// 2obj is created non static class
		OuterClass outer = new OuterClass();
		OuterClass.InnerClass inner =outer.new InnerClass();
		inner.display();
	}

}
