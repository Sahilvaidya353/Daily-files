package Assignment2;

public class Employee {

	
}

