package module2;
import java.util.Scanner;

public class EducationDepartment {
private  String DepartmentType;
private int NoOfFaculty,ceid,age;
private int NoOFStudents;
private String TypeOfCourse;
private String name,gender;
private int marks;

Scanner sc= new Scanner(System.in);

public void accept() {
	System.out.println("Enter Department type");
	DepartmentType = sc.next();
	System.out.println("Enter Number of faculty,ID,age");
	NoOfFaculty=sc.nextInt();
	ceid=sc.nextInt();
	age=sc.nextInt();
	System.out.println("Enter number of student");
	NoOFStudents=sc.nextInt();
	System.out.println("Enter the type of Department");
	
	
}

}
