package module2;
import java.util.Scanner; 
public class Student {
  private int rollno;
  private String name;
  private double score;
  
  Scanner sc=new Scanner(System.in);

  public void accept() {
	  
	  System.out.println("Enter the Roll No");
	  rollno = sc.nextInt();
	  System.out.println("Enter the Name");
	   name =sc.next();
	  System.out.println("Enter the score");
	  score=sc.nextInt();
  }
public void attendClass() {
	System.out.println("Attending the class");
}
public void appearExam() {
	System.out.println("Appearing for the exams");
}
public void completeassignment() {
	System.out.println("Completing the assignment");
}
public void display() {
	System.out.println("Name"+name);
	System.out.println("Roll no"+rollno);
	System.out.println("Score"+score);
}
}