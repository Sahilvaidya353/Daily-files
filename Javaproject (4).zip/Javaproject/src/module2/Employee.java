package module2;

import java.util.Scanner;

public class Employee {
  private int empNo;
  private String ename;
  private double empSalary;
  
  Scanner sc=new Scanner(System.in);
  
  public void accept() {
	  System.out.println("Enter Employee No");
	  empNo = sc.nextInt();
	  System.out.println("Enter the Employee Name");
	  ename =sc.next();
	  System.out.println("Enter Salary of employee");
	  empSalary=sc.nextInt();
  }
  public void completeProject() {
		System.out.println("Completed the project");
	}
  public void checkAttendance() {
		System.out.println("Checking the attendance");
	}
  public void applyLoan() {
		System.out.println("Applying for loan");
	}
  public void display() {
		System.out.println("Employee name"+ename);
		System.out.println("Employee No"+empNo);
		System.out.println("Salary of employee"+empSalary);
}
}
