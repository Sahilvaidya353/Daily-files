package module2;

public class Teststudent {
	public static void main(String[] args) {
		Student student = new Student();
		
		//student.accept();
		student.display();
		student.attendClass();
		student.appearExam();
		student.completeassignment();
		
		Student student2 = new Student();
		
		//student2.accept();
		student2.display();
		student2.attendClass();
		student2.appearExam();
		student2.completeassignment();
	}

}
