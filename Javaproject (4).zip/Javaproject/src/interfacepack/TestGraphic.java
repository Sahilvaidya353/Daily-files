package interfacepack;

public class TestGraphic {

	public static void main(String[] args) {
		Circle circle = new Circle(3);
		System.out.println("The area of circle is"+circle.area() );
		System.out.println("The perimeter of circle is"+circle.perimeter() );
		
		System.out.println("=====================");
		
		Recatangle rectangle = new Recatangle(3, 4);
		System.out.println("The area of rectangle is "+rectangle.area());
		System.out.println("The perimeter of rectangle is"+rectangle.perimeter());

	}

}
