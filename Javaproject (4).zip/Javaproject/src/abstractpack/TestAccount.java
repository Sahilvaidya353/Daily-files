package abstractpack;

public class TestAccount {


  public static void main(String[] args) {
		CurrentAccount currentaccount = new CurrentAccount(23, 30000);
		currentaccount.calculateInterest();
		SavingsAccount savingsAccount = new SavingsAccount(24,40000);
		savingsAccount.calculateInterest();
		LoanAccount  loanAccount = new  LoanAccount(25, 50000);
		loanAccount.calculateInterest();
	}
}

