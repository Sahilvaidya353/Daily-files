package module1;

public class Student {
private int rollno;
private String name;
private  double score;

public void attendClass() {
	System.out.println("Attending the class");
}
public void appearExam() {
	System.out.println("Appearing for the exams");
}
public void completeassignment() {
	System.out.println("Completing the assignment");
}
public void display() {
	System.out.println("Name"+name);
	System.out.println("Roll no"+rollno);
	System.out.println("Score"+score);
}

public static void main(String args[]) {
	System.out.println("Creating an object");
	Student student = new Student();
	
	student.name="Sahil";
	student.rollno=52;
	student.score=90.86;
	
	System.out.println("calling the mf");
	student.display();
	
	System.out.println("===============");
	Student student2 = new Student();
	student2.name="Yash";
	student2.rollno=82;
	student2.score=88.86;
	
	System.out.println("calling the mf");
	student2.display();
}
}
