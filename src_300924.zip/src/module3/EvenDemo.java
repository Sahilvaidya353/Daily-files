package module3;

import java.util.Scanner;

public class EvenDemo {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the number");
		int n=sc.nextInt();
		int a=1;
		while(a<=n) {
			if(a%2==0)
				System.out.println(a);
			a++;
		}
	}
}
