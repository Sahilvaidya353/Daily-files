package module2;

public class Testemployee {
	public static void main(String[] args) {
		
		Employee employee = new Employee();
		
		employee.accept();
		employee.applyLoan();
		employee.completeProject();
		employee.checkAttendance();
		employee.display();
		
		System.out.println("==============");
		System.out.println("Creating 2nd object");
		
		Employee employee2 = new Employee();
		
		employee2.accept();
		employee2.applyLoan();
		employee2.completeProject();
		employee2.checkAttendance();
		employee2.display();
	}
}
