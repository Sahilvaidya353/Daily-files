package module2;

public class TestEducationDepartment {
	public static void main(String [] args) {
		
	}

}
