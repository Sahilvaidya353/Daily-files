package module5;

public class OverloadMain {
	public void main() {
		System.out.println("Main method without parameters");
	}
	public void main(int a,int b) {
	System.out.println("Main method with 2 parameters");
}
	public void main(int a) {
	System.out.println("Main method with 1 parameters");
}

	public static void main(String[] args) {
		OverloadMain obj = new OverloadMain();
		obj.main();
		obj.main(34);
		obj.main(34, 56);

	}

}
