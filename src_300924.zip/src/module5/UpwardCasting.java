package module5;

public class UpwardCasting {
	public static void main(String[] args) {
		int a=200;
		double d=a;   //upward casting
		System.out.println(d);
		
		double d1=89.34;
		int i=(int)d1;		//explicit casting
		System.out.println(i);
	}
	

}
