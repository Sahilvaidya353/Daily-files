package module6;

public class WrapperDemo {

	public static void main(String[] args) {
		String str = "100";
		String str1 = "200";
		String str2 = "198.77";
		String str3 = "250.88";
		System.out.println("================");
		System.out.println("Total is" + (Integer.parseInt(str) + Integer.parseInt(str1)));
		System.out.println("================");
		System.out.println("Total is" + (Double.parseDouble(str2) + Double.parseDouble(str3)));
		System.out.println("================");
		System.out.println("Total is" + (Float.parseFloat(str2) + Float.parseFloat(str3)));
		System.out.println("================");
		//Wrapper classes = wraps primitive data type
		System.out.println(Byte.MAX_VALUE);  //127
		System.out.println(Short.MAX_VALUE);
		System.out.println(Integer.MAX_VALUE);
		System.out.println(Long.MAX_VALUE);
		System.out.println(Byte.MIN_VALUE);

	}

}
