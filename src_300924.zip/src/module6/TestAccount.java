package module6;

public class TestAccount {

	public static void main(String[] args) {
		Account account=new Account();
		account.setAccBalance(50000);
		account.setAccNo(4566);
		account.setAccName("yash");
		System.out.println(account);
		
		System.out.println("==============");
		Account account1=new Account(1323442,"Sahil",1000000);
		System.out.println(account1);

	}

}
