package module6;
import java.util.Scanner;
public class TestStudent {

	public static void main(String[] args) {
		Scanner sc =new Scanner(System.in);
		System.out.println("Enter rollno,name,score");
		int rollNo=sc.nextInt();
		String name=sc.next();
		double score=sc.nextInt();
		
		// set the value
		Student student = new Student();
		student.setRollNo(rollNo);
		student.setName(name);
		student.setScore(score);
		
		//student.display();
		System.out.println("Displaying the details");
		System.out.println("rollno is"+student.getRollNo());
		System.out.println("name is "+ student.getName());
		System.out.println("score is "+ student.getScore());
		
		student.markAttendance();

		System.out.println("==============");
		System.out.println("Creating an obj with parameters");
		Student student2 = new Student(52, "sahil", 95);
		//student2.display();
		System.out.println("Displaying the details");
		System.out.println("rollno is"+student2.getRollNo());
		System.out.println("name is "+ student2.getName());
		System.out.println("score is "+ student2.getScore());
		student2.markAttendance();
		
		System.out.println("==================");
		System.out.println("changing the name");
		System.out.println("Enter the new name");
		String name1=sc.next();
		student2.setName(name1);
		System.out.println("new name is "+student2.getName());
		System.out.println("Enter the new rollNo");
		int rollNo1=sc.nextInt();
		student2.setRollNo(rollNo1);
		System.out.println("new roll is"+student2.getRollNo());
		System.out.println("Enter the new score");
		double score1=sc.nextDouble();
		student2.setScore(score1);
		System.out.println("new score is"+student2.getScore());
	}

}
