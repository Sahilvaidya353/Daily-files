package entity;

public class exception {
	public class InvalidOrderException extends Exception {
	    public InvalidOrderException(String message) {
	        super(message);
	    }
	}
}



