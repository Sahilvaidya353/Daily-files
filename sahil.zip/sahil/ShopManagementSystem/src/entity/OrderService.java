package entity;

import java.util.ArrayList;
import java.util.List;

public class OrderService {
    private List<Order> orders;

    public OrderService() {
        this.orders = new ArrayList<>();
    }

    public void addOrder(Order order) {
        orders.add(order);
    }
    public void displayAllOrders() {
        System.out.println("Displaying all the Orders ");
        for (Order order : orders) {
            order.display();
        }
    }
    public void saveAllOrdersToFile(String myfile) {
        for (Order order : orders) {
            order.saveorderToFile(myfile);
        }
    }
}




