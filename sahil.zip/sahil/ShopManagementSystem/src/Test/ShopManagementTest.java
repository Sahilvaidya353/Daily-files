package Test;

import java.io.BufferedReader;
import java.io.InputStreamReader;

import entity.Customer;
import entity.Order;
import entity.OrderService;
import entity.Product;
	

	public class ShopManagementTest {
		    public static void main(String[] args) {
		        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
		        OrderService orderService = new OrderService();

		        try {
		            
		            System.out.print("Creating the number of orders ");
		            int numberOfOrders = Integer.parseInt(reader.readLine());

		            for (int i = 0; i < numberOfOrders; i++) {
		                System.out.println(" Order " + (i + 1) + " ");

		                System.out.print("Enter customer name: ");
		                String customerName = reader.readLine();
		                System.out.print("Enter customer contact: ");
		                String customerContact = reader.readLine();
		                Customer customer = new Customer(customerName, customerContact);
		               
		                Order order = new Order(customer);
		                while (true) {
		                    System.out.print("Enter product name (or 'done' to finish): ");
		                    String productName = reader.readLine();
		                    if (productName.equalsIgnoreCase("done")) {
		                        break;
		                    }
		                    System.out.print("Enter product price: ");
		                    double productPrice = Double.parseDouble(reader.readLine());
		                    Product product = new Product(productName, productPrice);
		                    order.addProduct(product);
		                }
		                    orderService.addOrder(order);
		                    order.display();
		            	}
		            		orderService.saveAllOrdersToFile("orders.txt");
		            		orderService.displayAllOrders();

		        } catch (NumberFormatException e) {
		            System.out.println("Invalid input: Please enter numeric values for order count.");
		        } catch (Exception e) {
		            System.out.println("An error occurred: " + e.getMessage());
		        }
		    }
		}
	
