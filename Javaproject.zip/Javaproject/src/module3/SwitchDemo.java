package module3;
import java.util.Scanner;
public class SwitchDemo {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the number");
		int num = sc.nextInt();
		switch(num) {
		case 5:  
			System.out.println("Its movie time");
			break;
		case 6:
			System.out.println("Its super saturday");
			break;
		case 7:
			System.out.println("Its Holiday");
			break;
		default:
			System.out.println("Its is working day");
		}

	}

}
