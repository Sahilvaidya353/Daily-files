package module2;

public class mathdemo {
	public static void main(String args[]) {
		System.out.println(Math.sqrt(144));
		System.out.println(Math.abs(-78));
		System.out.println(Math.max(34, 67));
		System.out.println(Math.min(34,78));
		System.out.println("no is "+Math.random());
		double d=(int)(Math.random() * 100);
		System.out.println("D is "+d);
		System.out.println(Math.round(676.99));
		System.out.println(Math.ceil(745.78));
		System.out.println(Math.floor(745.23));
		System.out.println(Math.round(745.68));
		System.out.println(Math.pow(4, 4));
		System.out.println(Math.addExact(45, 34));
		System.out.println(Math.subtractExact(67, 34));
		
	}
}
