package Assignment;
import java.util.Scanner;
public class Assignment1 {
private String name;
private int age;
private double salary;

Scanner sc=new Scanner(System.in);

public void accept() {

	  System.out.println("Enter the Name");
	  name = sc.next();
	  System.out.println("Enter the Age");
	  age =sc.nextInt();
	  System.out.println("Enter the Salary");
	  salary=sc.nextDouble();
}
public void loanEligible() {
	if(age>18 && age<60 && salary>25000) {
		System.out.println("You are eligible for loan");
		System.out.println(age+"=Valid age");
		System.out.println(salary+" =Salary is valid");
		
	}
	else
		System.out.println("your are not eligible for loan");
	}
public void Display() {	
		System.out.println("Name of person ="+name);
		System.out.println("Age of person ="+age);
		System.out.println("Salary of person ="+salary);
}
}


