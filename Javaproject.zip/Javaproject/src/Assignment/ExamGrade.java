package Assignment;
import java.util.Scanner;
public class ExamGrade {

}
