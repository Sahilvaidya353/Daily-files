package Inheritance;

public class SchoolEducation extends Department {
protected int noOfTeachers;
protected int subjects;
public SchoolEducation(String deptName, int courses, int noOfPepole, int noOfTeachers, int subjects) {
	super(deptName, courses, noOfPepole);
	this.noOfTeachers = noOfTeachers;
	this.subjects = subjects;
}
@Override
public String toString() {
	return "SchoolEducation [noOfTeachers=" + noOfTeachers + ", subjects=" + subjects + ", deptName=" + deptName
			+ ", courses=" + courses + ", noOfPepole=" + noOfPepole + "]";
}


}
