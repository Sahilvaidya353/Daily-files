package Inheritance;

public class TestPerson2 {

	public static void main(String[] args) {
		//creating an array objects
		Person[] arr=new Person[5];
		arr[0]= new Person("sahil",24,'M');
		arr[1]= new Person("Yash",17,'M');
		arr[2]= new Person("siddhant",22,'M');
		arr[3]= new Person("chinmay",24,'M');
		arr[4]= new Person("Noor",23,'M');
		
		for(int i=0;i<arr.length;i++) {
			System.out.println(arr[i].getName() + " is " +
			arr[i].getAge()+"years old and gender is"+arr[i].getGender());
		}
	}

}
