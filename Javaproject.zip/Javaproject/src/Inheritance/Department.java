package Inheritance;

public class Department {
protected String deptName;
protected int    courses;
protected int noOfPepole;
public Department(String deptName, int courses, int noOfPepole) {
	super();
	this.deptName = deptName;
	this.courses = courses;
	this.noOfPepole = noOfPepole;
}
@Override
public String toString() {
	return "Department [deptName=" + deptName + ", courses=" + courses + ", noOfPepole=" + noOfPepole + "]";
}




}
