package userinterface;
import entity.Account;
import operations.AccountOperations;
import java.util.Scanner;

public class TestAccount {

	public static void main(String[] args) {
		Account account = new Account(1,"Sahil",90000);
		Account account1 = new Account(2,"siddhant",85000);
		AccountOperations accountOperations = new AccountOperations();
		
		int ch;
		String choice;
		Scanner sc = new Scanner(System.in);
		do {
			System.out.println("ICICI Bank");
			System.out.println("1. Accept Details");
			System.out.println("2. Display Details");
			System.out.println("3. Withdraw Amount");
			System.out.println("4. Deposit Amount");
			System.out.println("5. Transfer Amount");
			System.out.println("6. Check balance");
			System.out.println("7. Update Balance");
			System.out.println("8. Exit");

			System.out.println("Enter your Choice");
			ch = sc.nextInt();

			switch (ch) {
			case 1:
				System.out.println("Accept Details");
				break;
			case 2:
				System.out.println("Display Details");
				System.out.println("accNO is"+account1.getAccNo());
				System.out.println("accNo is"+account1.getAccHolderName());
				System.out.println("name is"+account1.getBalance());
				break;
			case 3:
				System.out.println("Enter the amount to Withdraw.... ");
				double amount=sc.nextDouble();
				boolean result=accountOperations.withdraw(account1, amount);
				if(result==true) {
					System.out.println("Withdraw is sucessfull");
					System.out.println("The new balance is"+account1.getBalance());
				}
				else
					System.out.println("Withdraw is failed");
				break;
			case 4:
				
				System.out.println("Enter the Deposit Amount");
				System.out.println("===============");
				amount= sc.nextDouble();
		
				result=accountOperations.deposit(account1, amount); 
				if(result==true) {
					System.out.println("Deposit amount is sucessfull");
					System.out.println("The new balance is "+account.getBalance());
				}
				else
					System.out.println("Deposit is failed");
				break;
			case 5:
				System.out.println("===============");
				System.out.println("Transfer Amount");
				amount = sc.nextDouble();
				System.out.println("account old balance is"+account.getBalance());
				System.out.println( "account1 old balance is"+account1.getBalance());
				result=accountOperations.transfer(account, account1, amount);
				if(result==true) {
					System.out.println("Transfer is sucessfull......!");
					System.out.println("account new balance is"+account.getBalance());
					System.out.println("account new balance is"+account1.getBalance());
				}else 
					System.out.println("Transfer is failed.....");
				break;
			case 6:
				System.out.println("Check balance");
				break;
			case 7:
				System.out.println("Update Balance");
				break;
			case 8:
				System.out.println("Thanks for visitint ....");
				System.exit(0);

			}
			System.out.println("Do you want to continue?(y/n)");
			choice = sc.next();

		} while (choice.equalsIgnoreCase("Y"));
		System.out.println("Thanks for visitint ....");
	}

}
